
MODULE meric
#include "meric_fortran_interface.h90"
END MODULE meric

