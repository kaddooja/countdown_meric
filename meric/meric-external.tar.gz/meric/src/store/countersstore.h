
#ifndef SRC_STORE_COUNTERSSTORE_H_
#define SRC_STORE_COUNTERSSTORE_H_

#include <iomanip>
#include "store.h"

namespace meric {

template <typename TType>
struct CountersRecord {
	CountersRecord(int region, std::map <std::string, TType> record, timespec time, RegionParameters configuration)
	: region(region), record(record), time(time), configuration(configuration) {};
	CountersRecord() : region(-1){};
	
	int region;
	std::map <std::string, TType> record;
	timespec time;
	RegionParameters configuration;
};

template <class TStore>
class CountersAggregateStore;

template <class TCounter, typename TType, typename RType> class CountersStore: public Store {

	friend class CountersAggregateStore<CountersStore>;
public:
	typedef TType dataType;
	typedef RType resultType;
	typedef TCounter counterType;
	void addStart(int region, RegionParameters configuration);
	void addEnd(int region);
	double getRegionDuration() {return 0.0;};
	void fillRegionStats(std::vector<RType> &stats, std::map <std::string, double> &ratios, size_t iStarts, size_t iEnd);

	void save(const std::string outputDir, const std::string outputFilename, std::vector<std::string> regionNames, const std::string prefix = "")
	{
		_name = regionNames; 
        iterate(_records, prefix, outputDir, outputFilename); 
    }
    
	void save(const std::string prefix, const std::string outputDir, const std::string outputFilename,
              std::function<void(std::ofstream &ss, std::vector<size_t> &iStarts, size_t iEnd)> processInterval)
	{
		iterate(_records, prefix, outputDir, outputFilename, processInterval);
	}
	
	void save(std::function<void(std::vector<size_t> &iStarts, size_t iEnd)> processInterval)
	{
		iterate(_records, processInterval);
	}
	
	CountersStore(bool write = true) : Store(false, write)
	{
		MERIC_INFO << "Create CountersStore - " << TCounter::getSourceLabel() << std::endl;
	}
	
	CountersStore(bool samples, bool write) : Store(false, write) // required for AggregateStoreBase constructor
	{
		MERIC_INFO << "Create CountersStore - " << TCounter::getSourceLabel() << std::endl;
	}

protected:
	void saveInterval(std::ofstream &ss, std::vector<size_t> &iStarts, size_t iEnd);
	std::vector<CountersRecord<TType>> _records;
};

}


#endif /* SRC_STORE_COUNTERSSTORE_H_ */
