#pragma once

#include <string>

bool writeSlaveScript(const std::string& outPath, const std::string& masterIp);
