#pragma once

#include <string>

std::string detectPrimaryIPv4();
